/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centro_médico;

import java.sql.Date;

/**
 *
 * @author User
 */
public class Metodos {
    
    // paciente
     int cedula_paciente;
     Date fecha_nacimiento_;

public Metodos(){}

 public Metodos(int cedula_paciente, Date fecha_nacimiento_) {
        this.cedula_paciente = cedula_paciente;
        this.fecha_nacimiento_ = fecha_nacimiento_;
    }
    public int getCedula_paciente() {
        return cedula_paciente;
    }

    public void setCedula_paciente(int cedula_paciente) {
        this.cedula_paciente = cedula_paciente;
    }

    public Date getFecha_nacimiento_() {
        return fecha_nacimiento_;
    }

    public void setFecha_nacimiento_(Date fecha_nacimiento_) {
        this.fecha_nacimiento_ = fecha_nacimiento_;
    }

   
    //persona
     int cedula;
     String nombre;
     String apellido;
     String email;
     int telefono;

    public Metodos(int cedula, String nombre, String apellido, String email, int telefono) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.telefono = telefono;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }
     
    // usuario
    int id_usuario;
    String contrasenia;

    public Metodos(int id_usuario, String contrasenia) {
        this.id_usuario = id_usuario;
        this.contrasenia = contrasenia;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }
  
    // medico
    int tarjeta_prof;
    String especialidad;
    int cedula_medico;

    public Metodos(int tarjeta_prof, String especialidad, int cedula_medico) {
        this.tarjeta_prof = tarjeta_prof;
        this.especialidad = especialidad;
        this.cedula_medico = cedula_medico;
    }

    public int getTarjeta_prof() {
        return tarjeta_prof;
    }

    public void setTarjeta_prof(int tarjeta_prof) {
        this.tarjeta_prof = tarjeta_prof;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public int getCedula_medico() {
        return cedula_medico;
    }

    public void setCedula_medico(int cedula_medico) {
        this.cedula_medico = cedula_medico;
    }
    
    // agenda
     //cita
   
}
