package centro_médico;

import java.awt.event.ItemEvent;
import java.sql.*;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class AGENDAR extends javax.swing.JFrame {
    java.util.Date fecha=new java.util.Date();
    int [] vector_id;
    int [] vector_cant;//agregar 
    String [] informacion;
    String [] informacion1;
    private int cedula_paciente;
    int id_paciente;
    
    public void mostrar_datos(int cedula_paciente,int id_paciente){
        this.cedula_paciente=cedula_paciente;
        this.id_paciente=id_paciente;
    }
    
    public AGENDAR() {
        initComponents();
        this.setTitle("AGENDAR CITAS");
        this.setLocationRelativeTo(null);
    }
    
    public String[] datos (String datos){
              BaseDatos cc=new BaseDatos();
            Connection cn=cc.conexion();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
            String fechaComoCadena;
            fechaComoCadena=sdf.format(fecha_validar.getDate());
            Statement stmt = null;
            String sql2="select COUNT(distinct m.nombre||' '||m.apellido) as total from medico m inner join agenda a on m.cedula_medico=a.cedula_medico where\n" + 
            "(m.especialidad=? and (a.fecha_ini)>=(to_date(?, 'YYYY/MM/DD')+interval'7 days') and a.cant_citas<3) ";
            int cantidad=0;
            try{
                PreparedStatement pst1= cn.prepareStatement(sql2);
                pst1.setString(1,ESPECIALIDAD.getSelectedItem().toString());
                pst1.setString(2, fechaComoCadena);
                ResultSet rs1 = pst1.executeQuery();
                if(rs1.next()){
                 cantidad=rs1.getInt("total");
                }
                pst1.close();
                rs1.close();
            } catch (SQLException ex) {
                Logger.getLogger(AGENDAR.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "*ERROR*");
            }
            informacion=new String[cantidad+1];
            if(fecha_validar.getDate().after(fecha)){
            String sql="select m.nombre||' '||m.apellido as Nombrecompleto from medico m inner join agenda a on m.cedula_medico=a.cedula_medico where\n" + 
            "(m.especialidad=? and (a.fecha_ini)>=(to_date(?, 'YYYY/MM/DD')+interval'7 days') and a.cant_citas<3) group by Nombrecompleto";
            boolean bandera=false;
            try{
                PreparedStatement pst= cn.prepareStatement(sql);
                pst.setString(1,ESPECIALIDAD.getSelectedItem().toString());
                pst.setString(2, fechaComoCadena);
                ResultSet rs = pst.executeQuery();
                int posicion=0;
                while(rs.next()){
                    bandera=true;
                        informacion [0] = "seleccionar";
                        posicion++;
                        informacion [posicion] = rs.getString("Nombrecompleto");
                }
                if(bandera==false){
                JOptionPane.showMessageDialog(null, "No hay medicos disponibles");
                }
                
                pst.close();
                rs.close();
                cn.close();
            } catch (SQLException ex) {
                Logger.getLogger(AGENDAR.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "*ERROR*");
            }
            }else{
                JOptionPane.showMessageDialog(null, "No puede sacar un cita para días anteriores");
                fecha_validar.setCalendar(null);
                ESPECIALIDAD.setSelectedIndex(0);
            }
            return informacion;
      }
    
    public String[] datos1 (String datos){
            BaseDatos cc=new BaseDatos();
            Connection cn=cc.conexion();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
            String fechaComoCadena;
            fechaComoCadena=sdf.format(fecha_validar.getDate());
            Statement stmt = null;
            int cantidad=0;
            String sql="SELECT COUNT(a.fecha_ini) as total FROM medico m inner join agenda a on m.cedula_medico=a.cedula_medico WHERE \n" +
            "(m.nombre||' '||m.apellido like ? and (a.fecha_ini)>=(to_date(?, 'YYYY/MM/DD')+interval'7 days') and a.cant_citas<3)";
            try{
                PreparedStatement pst1= cn.prepareStatement(sql);
                pst1.setString(1,MEDICOS.getSelectedItem().toString());
                pst1.setString(2, fechaComoCadena);
                ResultSet rs1 = pst1.executeQuery();
                if(rs1.next()){
                 cantidad=rs1.getInt("total");
                }
                pst1.close();
                rs1.close();
            } catch (SQLException ex) {
                Logger.getLogger(AGENDAR.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "*ERROR*");
            }
            informacion1=new String[cantidad+1];
            vector_id=new int[cantidad+1];
            vector_cant=new int[cantidad+1];//agregar
            String sql2="SELECT a.fecha_ini,a.id_agenda,a.cant_citas FROM medico m inner join agenda a on m.cedula_medico=a.cedula_medico WHERE \n" +
            "(m.nombre||' '||m.apellido like ? and (a.fecha_ini)>=(to_date(?, 'YYYY/MM/DD')+interval'7 days') and a.cant_citas<3)";
            try{
                PreparedStatement pst= cn.prepareStatement(sql2);
                pst.setString(1, MEDICOS.getSelectedItem().toString());
                pst.setString(2, fechaComoCadena);
                ResultSet rs = pst.executeQuery();
                int posicion=0;
                while(rs.next()){
                  informacion1[0]="seleccionar";
                  posicion++;
                  informacion1 [posicion] = rs.getTimestamp("fecha_ini").toString();
                  vector_id[posicion]=rs.getInt("id_agenda");
                  vector_cant[posicion]=rs.getInt("cant_citas");//agregar
                }
                pst.close();
                rs.close();
                cn.close();
            } catch (SQLException ex) {
                Logger.getLogger(AGENDAR.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "*ERROR*");
            }
            return informacion1;
      }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        MEDICOS = new javax.swing.JComboBox<>();
        ESPECIALIDAD = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        fecha1 = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        fecha_validar = new com.toedter.calendar.JDateChooser();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 255));

        jLabel1.setText("CITAS");

        jLabel3.setText("FECHA");

        jLabel4.setText("MÉDICO");

        jLabel5.setText("ESPECIALIDAD");

        MEDICOS.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                MEDICOSItemStateChanged(evt);
            }
        });
        MEDICOS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MEDICOSActionPerformed(evt);
            }
        });

        ESPECIALIDAD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "seleccionar", "medicina general", "odontologia", "pediatria", "ginecologia" }));
        ESPECIALIDAD.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ESPECIALIDADItemStateChanged(evt);
            }
        });
        ESPECIALIDAD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ESPECIALIDADActionPerformed(evt);
            }
        });

        jButton1.setText("CONFIRMAR CITA");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("SALIR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel2.setText("HORARIOS DISPONIBLES");

        fecha_validar.setDateFormatString("yyyy/MM/dd");

        jButton3.setText("LIMPIAR");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(427, 427, 427)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2)
                            .addGap(34, 34, 34)
                            .addComponent(jButton1)
                            .addGap(58, 58, 58)
                            .addComponent(jButton3))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addGap(177, 177, 177)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel4)
                                .addComponent(jLabel2)
                                .addComponent(jLabel5)
                                .addComponent(jLabel3))
                            .addGap(80, 80, 80)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(MEDICOS, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(ESPECIALIDAD, 0, 192, Short.MAX_VALUE)
                                .addComponent(fecha1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(fecha_validar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap(126, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(fecha_validar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ESPECIALIDAD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MEDICOS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fecha1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 103, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(63, 63, 63))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MEDICOSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MEDICOSActionPerformed

    }//GEN-LAST:event_MEDICOSActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if(fecha_validar.getCalendar()!=null){
    int pos=0,pos2=0;//agregar
            for (int r = 1; r < vector_id.length; r++) {
                if(informacion1[r]==fecha1.getSelectedItem()){
                    pos=vector_id[r];
                    pos2=vector_cant[r];//agregar
                }
            }
            BaseDatos cc=new BaseDatos();
            Connection cn=cc.conexion();
            Statement stmt = null;
            String sql="INSERT INTO cita (estado,tipo,cedula_paciente,id_agenda) VALUES(?,?,?,?)";
            String sql2="UPDATE agenda SET cant_citas=? where id_agenda=?";//agregar
            try{
                PreparedStatement pst5=cn.prepareStatement(sql2);
                pst5.setInt(1, pos2+1);
                pst5.setInt(2,pos);//agregar
                int n1=pst5.executeUpdate();
                if(n1>0){
                PreparedStatement pst1= cn.prepareStatement(sql);
                pst1.setString(1, "Agendada");
                pst1.setString(2, ESPECIALIDAD.getSelectedItem().toString());
                pst1.setInt(3, cedula_paciente);
                pst1.setInt(4, pos);
                int n=pst1.executeUpdate();
                if(n>0){
                JOptionPane.showMessageDialog(null,"Registro guardado con exito");
                JOptionPane.showMessageDialog(null, "Para la Cita debe estar con 15 minutos de antelación. \n No olvide llevar tapabocas y cédula de ciudadania");
                }
                pst1.close();
                }
                pst5.close();//agregar
                cn.close();
            } catch (SQLException ex) {
                Logger.getLogger(AGENDAR.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "*ERROR*");
            }
    }else{
        JOptionPane.showMessageDialog(null, "Debe seleccionar una fecha para buscar las disponibilidades");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        PACIENTE pac=new PACIENTE();
        pac.mostrar_datos(id_paciente);
        pac.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void ESPECIALIDADActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ESPECIALIDADActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ESPECIALIDADActionPerformed

    private void MEDICOSItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_MEDICOSItemStateChanged
        if (evt.getStateChange()==ItemEvent.SELECTED){
        if(this.MEDICOS.getSelectedIndex()>0){
         this.fecha1.setModel(new DefaultComboBoxModel(this.datos1(this.MEDICOS.getSelectedItem().toString())));
        }
       }
    }//GEN-LAST:event_MEDICOSItemStateChanged

    private void ESPECIALIDADItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ESPECIALIDADItemStateChanged
    if (evt.getStateChange()==ItemEvent.SELECTED){
     if(this.ESPECIALIDAD.getSelectedIndex()>0){
      this.MEDICOS.setModel(new DefaultComboBoxModel(this.datos(this.ESPECIALIDAD.getSelectedItem().toString())));
     }
    }
    }//GEN-LAST:event_ESPECIALIDADItemStateChanged

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        fecha_validar.setCalendar(null);
        ESPECIALIDAD.setSelectedIndex(0);
        MEDICOS.removeAllItems();
        fecha1.removeAllItems();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AGENDAR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AGENDAR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AGENDAR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AGENDAR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AGENDAR().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ESPECIALIDAD;
    private javax.swing.JComboBox<String> MEDICOS;
    private javax.swing.JComboBox<String> fecha1;
    private com.toedter.calendar.JDateChooser fecha_validar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables


}
