/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centro_médico;

/**
 *
 * @author Acer Aspire E15 Star
 */
public class CENTRO_MEDICO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ventana_inicio inicio=new ventana_inicio();
        inicio.setVisible(true);
    }
    
}
