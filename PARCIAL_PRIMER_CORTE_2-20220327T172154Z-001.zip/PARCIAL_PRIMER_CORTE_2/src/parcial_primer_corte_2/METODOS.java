
package parcial_primer_corte_2;


public class METODOS {

    int codigo,cantida_culti,cantida_vendida;
    float precio_venta;
    
    public METODOS(int codigo,int cantida_culti,int cantida_vendida,float precio_venta) {
        
       this.cantida_culti=cantida_culti;
       this.codigo=codigo;
       this.cantida_vendida=cantida_vendida;
       this.cantida_culti=cantida_culti;
       this.precio_venta=precio_venta;
    }

    public int getCodigo() {
        return codigo;
    }

    public int getCantida_culti() {
        return cantida_culti;
    }

    public int getCantida_vendida() {
        return cantida_vendida;
    }

    public float getPrecio_venta() {
        return precio_venta;
    }
    
    public void imprimir(){
        
        System.out.println("El codigo del producto más vendido es: "+codigo+" Con "+cantida_vendida+" cantidades vendidas");
    }

    public void imprimir2(){
        
        System.out.println("El codigo del producto menos prooducido es: "+codigo+" Con "+cantida_culti+" cantidades cultivadas");
    }
    
    
    
}
