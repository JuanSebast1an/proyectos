
package parcial_primer_corte_2;

import java.util.Scanner;
public class PARCIAL_PRIMER_CORTE_2 {
    
    static float total_ventas=0,precio_venta;
    static int codigo,cantida_culti,cantida_vendida;
    
    public static void imprimir_total_ventas(){
    
        System.out.println("El total de las ventas es: "+total_ventas);
    
    }
    
    public static void modificar(METODOS [] vec,int dimension){
    Scanner tec3=new Scanner (System.in);
        System.out.println("Que codigo desea modificar: ");
        int modificar=tec3.nextInt();
        int r,t=0,c=0;
        
        for ( r = 0; r < dimension; r++) {
            
            if(modificar==vec[r].codigo){
            t=0;
            c=r;
            }else{t=1;}
            
        }
        
        while(t==1){
            System.out.println("El codigo que digito no se encuentra por favor digite otro");
            System.out.println("Que codigo desea modificar: ");
         modificar=tec3.nextInt();
         t=0;
        
        for ( r = 0; r < dimension; r++) {
            
            if(modificar==vec[r].codigo){
            t=0;
            c=r;
            }else{t=1;}
            
        }
        }
        
        System.out.println("Que desea modificar ");
        System.out.println("1.Cantidad cutivada");
        System.out.println("2.cantidad vendida");
        int op=tec3.nextInt();
        if(op==1){
            System.out.println("Digite la cantidad cultivada: ");
            int tres=tec3.nextInt();
            vec[c].cantida_culti=tres;
        }else if(op==2){
            System.out.println("Digite la cantidad vendida: ");
            int cuatro=tec3.nextInt();
            vec[c].cantida_vendida=cuatro;
        }
        
        for (int fd = 0; fd < dimension; fd++) {
            
            total_ventas+=vec[fd].cantida_vendida*vec[fd].precio_venta;
            
        }
        
    
    }
    
    public static int menos_producido(METODOS vec[],int dimension){
    
    int indice=0;
        int t;
        t=vec[0].getCantida_culti();
        for(int p=1;p<dimension;p++){
            
            if(vec[p].getCantida_culti()<t){
                t=vec[p].getCantida_culti();
                indice=p;
            }
  
        }
        return indice;
    
    }
    
    public static int mas_vendido(METODOS vec[], int dimension){
        
        int indice=0;
        int t;
        t=vec[0].getCantida_culti();
        for(int p=1;p<dimension;p++){
            
            if(vec[p].getCantida_culti()>t){
                t=vec[p].getCantida_culti();
                indice=p;
            }
  
        }
        return indice;
   

    }
    
    public static void llenar_vector(int i,METODOS vec []){
        Scanner tec2=new Scanner(System.in);
        System.out.println("Digite codigo de la rosa: ");
        codigo=tec2.nextInt();
        System.out.println("Digite la cantidad cultivada: ");
        cantida_culti=tec2.nextInt();
        System.out.println("Digite cantidad vendida: ");
        cantida_vendida=tec2.nextInt();
        System.out.println("Digite precio de venta: ");
        precio_venta=tec2.nextInt();
        
        
        vec[i]=new METODOS(codigo,cantida_culti,cantida_vendida,precio_venta);
    
    }
    
    public static void main(String[] args) {
        Scanner tec=new Scanner(System.in);
        System.out.println("Cuantos tipos de rosas hay en la empresa?");
        int tipos=tec.nextInt();
        METODOS [] vec=new METODOS [tipos];
        
        for (int i = 0; i < tipos; i++) {
            
            llenar_vector(i,vec);
            
        }
        
        for (int f = 0; f < tipos; f++) {
            
            System.out.println(vec[f].getCantida_vendida());
            
        }
        
        int mas=mas_vendido(vec,tipos);
        System.out.println("El codigo del producto más vendido es: "+vec[mas].getCodigo()+" con "+vec[mas].getCantida_vendida()+" cantidades vendidas");
        
        
        int menos=menos_producido(vec,tipos);
        System.out.println("El codigo del producto menos producido es: "+vec[menos].getCodigo()+" con "+vec[menos].getCantida_culti()+" cantidades cultivadas");
        
        
        modificar(vec,tipos);

        imprimir_total_ventas();
        
    }
    
}
