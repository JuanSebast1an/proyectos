
package dijkstraalgorithm;

import java.util.*;

/**
 *
 * @author Juan Sebastian Duran Chacon
 */

public class DijkstraAlgorithm {

    
    public static void main(String[] args) {
        
        int E , origen, destino , peso , inicial, V;
        Scanner sc = new Scanner( System.in );      //para lectura de datos
        System.out.print("Ingrese el numero de vertices: ");
        V = sc.nextInt();
        System.out.print("Ingrese el numero de aristas: ");
        E = sc.nextInt();
        Dijkstra dijkstraAlgorithm = new Dijkstra(V);
        for( int i = 0 ; i < E ; ++i ){
            System.out.println("Digite vertice de origen");
            origen = sc.nextInt(); 
            System.out.println("Digite vertice de destino");
            destino = sc.nextInt(); 
            System.out.println("Digite peso de la arista");
            peso = sc.nextInt();
            dijkstraAlgorithm.addEdge(origen, destino, peso, true);
        }
        
        System.out.print("Ingrese el vertice inicial: ");
        inicial = sc.nextInt();
        dijkstraAlgorithm.dijkstra(inicial);
        dijkstraAlgorithm.printShortestPath();
    }
    
}
